// src/Home.js
import React from 'react';
import { useNavigate } from 'react-router-dom';


import './Welcome.css'; // Import CSS for styling

const Welcome = () => {
  const navigate = useNavigate();

  const handleNavigation = (path) => {
    navigate(path);
  };

  return (
    <div className="home-container">
      <div className="content-block">
        <h1 className="welcome-text">Welcome to the Customer International Payments Portal</h1>
        <p className="instruction-text">Would you like to Register or Login?</p> 
        <div className="button-container">
          <button onClick={() => handleNavigation('/register')}>Register</button>
          <button onClick={() => handleNavigation('/login')}>Login</button>
        </div>
      </div>
    </div>
  );
};

export default Welcome; 