import React, { useState } from 'react'; 
import { useNavigate } from 'react-router-dom';
import '../styles.css';

const Register = ({ onRegister }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    // Commenting out the API call for now
    /*
    try {
      const response = await axios.post('https://your-backend-url/api/users/register', { name, email, password });
      console.log('User registered:', response.data);
      onRegister(response.data.userName); // Call the onRegister function with the user's name
      navigate('/'); // Navigate to the main app page after successful registration
    } catch (error) {
      console.error('Error registering user:', error);
      alert('Registration failed. Please try again.'); // User feedback
    }
    */

    // Simulate a successful registration for testing
    console.log('User registered:', { name, email, password });
    onRegister(name); // Call the onRegister function with the user's name
    navigate('/'); // Navigate to the main app page after successful registration
  };

  return (
    <div className="register-container">
      <div className="register-content-block"
       style={{backgroundColor: '#f0f8ff', padding: '20px', borderRadius: '10px'}}>
        <h2 className="text-center">Register</h2>
        <form onSubmit={handleRegister}>
          <input 
            type="text" 
            placeholder="Name" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
            required 
          />
          <input 
            type="email" 
            placeholder="Email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
          />
          <input 
            type="password" 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  );
};

export default Register;